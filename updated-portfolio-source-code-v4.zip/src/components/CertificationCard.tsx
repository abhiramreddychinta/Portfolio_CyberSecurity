export default function CertificationCard({ 
  title, 
  issuer, 
  date,
  description 
}: { 
  title: string; 
  issuer: string; 
  date: string;
  description: string;
}) {
  return (
    <div className="glass-card p-6 rounded-xl hover:shadow-lg hover:shadow-primary/10 transition-all duration-300 hover:translate-y-[-2px]">
      <h3 className="font-semibold text-lg">{title}</h3>
      <div className="flex justify-between items-center">
        <p className="text-primary">{issuer}</p>
        <p className="text-sm text-foreground/60">{date}</p>
      </div>
      <p className="text-sm text-foreground/70 mt-3">{description}</p>
    </div>
  );
}
