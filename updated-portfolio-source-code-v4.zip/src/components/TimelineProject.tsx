import { useState, useEffect, useRef } from 'react';

interface TimelineProjectProps {
  title: string;
  date: string;
  description: string;
  technologies: string[];
}

export default function TimelineProject({ title, date, description, technologies }: TimelineProjectProps) {
  const [isVisible, setIsVisible] = useState(false);
  const projectRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.2 }
    );
    
    if (projectRef.current) {
      observer.observe(projectRef.current);
    }
    
    return () => {
      if (projectRef.current) {
        observer.unobserve(projectRef.current);
      }
    };
  }, []);
  
  return (
    <div 
      ref={projectRef}
      className={`relative pl-8 pb-10 transition-all duration-700 ${
        isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-10"
      }`}
    >
      {/* Timeline dot */}
      <div className="absolute left-[-8px] top-0 w-4 h-4 rounded-full bg-primary"></div>
      
      {/* Date badge */}
      <div className="inline-block px-3 py-1 rounded-full bg-secondary/30 text-xs mb-2">
        {date}
      </div>
      
      <h3 className="text-lg font-semibold mb-2">{title}</h3>
      <p className="text-sm text-foreground/80 mb-3 text-justify">{description}</p>
      
      <div className="flex flex-wrap gap-2">
        {technologies.map((tech, i) => (
          <span key={i} className="text-xs px-2 py-1 bg-primary/10 rounded-full text-primary">
            {tech}
          </span>
        ))}
      </div>
    </div>
  );
}
