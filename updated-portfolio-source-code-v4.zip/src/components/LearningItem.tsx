interface LearningItemProps {
  title: string;
  progress: number;
  description: string;
  resources: string[];
}

export default function LearningItem({ title, progress, description, resources }: LearningItemProps) {
  return (
    <div className="glass-card p-6 rounded-xl hover:shadow-lg hover:shadow-primary/10 transition-all duration-300">
      <div className="flex justify-between items-center mb-3">
        <h3 className="font-semibold">{title}</h3>
        <span className="text-xs px-2 py-1 bg-primary/20 rounded-full text-primary">
          {progress}% Complete
        </span>
      </div>
      
      <div className="w-full h-2 bg-secondary/30 rounded-full mb-4">
        <div 
          className="h-full bg-primary rounded-full" 
          style={{ width: `${progress}%` }}
        ></div>
      </div>
      
      <p className="text-sm text-foreground/80 mb-4 text-justify">{description}</p>
      
      <div className="space-y-2">
        <h4 className="text-xs font-medium uppercase text-foreground/60">Learning Resources:</h4>
        <ul className="space-y-1">
          {resources.map((resource, i) => (
            <li key={i} className="text-xs text-foreground/70 flex items-start gap-1.5">
              <span className="text-primary mt-0.5">•</span>
              <span>{resource}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
