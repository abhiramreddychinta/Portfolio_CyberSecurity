interface SkillBarProps {
  name: string;
  level: number; // 0-100
  color?: string;
}

export default function SkillBar({ name, level, color = "primary" }: SkillBarProps) {
  // Get the appropriate background color class based on the color prop
  const getBgColorClass = () => {
    if (color === "accent") return "bg-accent";
    return "bg-primary";
  };

  return (
    <div className="mb-4">
      <div className="flex justify-between items-center mb-1">
        <span className="text-sm font-medium">{name}</span>
        <span className="text-xs text-foreground/70">{level}%</span>
      </div>
      <div className="h-2 bg-secondary/30 rounded-full overflow-hidden">
        <div 
          className={`h-full ${getBgColorClass()} rounded-full`} 
          style={{ width: `${level}%`, transition: 'width 1s ease-in-out' }}
        ></div>
      </div>
    </div>
  );
}
