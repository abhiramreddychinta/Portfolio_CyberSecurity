interface TestimonialProps {
  quote: string;
  author: string;
  title: string;
  company: string;
}

export default function Testimonial({ quote, author, title, company }: TestimonialProps) {
  return (
    <div className="glass-card p-6 rounded-xl hover:shadow-lg hover:shadow-primary/10 transition-all duration-300">
      <div className="mb-4">
        <svg className="w-8 h-8 text-primary/40" fill="currentColor" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
          <path d="M10 8c-4.4 0-8 3.6-8 8v8h8v-8h-4c0-2.2 1.8-4 4-4v-4zm18-4c-4.4 0-8 3.6-8 8v8h8v-8h-4c0-2.2 1.8-4 4-4v-4z" />
        </svg>
      </div>
      <p className="text-sm text-foreground/80 mb-4 text-justify italic">{quote}</p>
      <div className="flex flex-col">
        <span className="font-semibold">{author}</span>
        <span className="text-xs text-foreground/60">{title}, {company}</span>
      </div>
    </div>
  );
}
