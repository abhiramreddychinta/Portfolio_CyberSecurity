import { useState, useEffect, useRef } from "react";
import { Menu, X, Download, Mail, Phone, ExternalLink, ChevronRight } from "lucide-react";
import CertificationCard from "./CertificationCard";

import SkillBar from "./SkillBar";
import Testimonial from "./Testimonial";
import BlogPost from "./BlogPost";
import TimelineProject from "./TimelineProject";
import LearningItem from "./LearningItem";

/**
 * A modern, cybersecurity-focused portfolio with:
 * – Dark theme with blue/purple accents
 * – Animated elements and transitions
 * – Glass-morphism effects
 * – Grid background patterns
 */

export default function Portfolio() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  const nav = [
    { href: "#home", label: "Home" },
    { href: "#about", label: "About" },
    { href: "#projects", label: "Projects" },
    { href: "#skills", label: "Skills" },
    { href: "#experience", label: "Experience" },
    { href: "#education", label: "Education" },
    { href: "#contact", label: "Contact" }
  ];

  return (
    <div className="scroll-smooth bg-background text-foreground min-h-screen selection:bg-accent/30 bg-grid bg-gradient-to-b from-background via-background/95 to-background/90">
      {/* Navbar */}
      <header className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${scrolled ? 'py-2' : 'py-4'}`}>
        <nav className={`mx-auto flex max-w-6xl items-center justify-between px-6 glass-card rounded-xl shadow-lg backdrop-blur-md ${scrolled ? 'shadow-accent/20' : 'shadow-primary/10'}`}>
          <div className="flex items-center gap-4">
            <a href="#home" className="font-bold text-xl tracking-wide hover:text-primary transition-colors">
              Abhiram Reddy Chinta<span className="text-accent">.</span>
            </a>
          </div>
          <button
            className="lg:hidden focus:outline-none"
            aria-label="Toggle menu"
            onClick={() => setOpen(!open)}
          >
            {open ? <X className="text-accent" /> : <Menu />}
          </button>
          <ul className={`lg:flex gap-6 font-medium ${open ? "block mt-4 space-y-3 pb-3" : "hidden"} lg:space-y-0 lg:mt-0`}>
            {nav.map((n) => (
              <li key={n.href}>
                <a
                  href={n.href}
                  onClick={() => setOpen(false)}
                  className="hover:text-primary transition-colors"
                >
                  {n.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>
      </header>

      {/* Hero */}
      <section
        id="home"
        className="flex flex-col lg:flex-row-reverse items-center justify-center min-h-screen gap-10 px-6 pt-28 pb-32 lg:pb-40 animate-fade-in"
      >
        {/* Decorative elements */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-primary/20 rounded-full filter blur-3xl animate-pulse-slow"></div>
          <div className="absolute bottom-1/4 left-1/3 w-64 h-64 bg-accent/20 rounded-full filter blur-3xl animate-pulse-slow" style={{animationDelay: '1s'}}></div>
        </div>
        
        {/* Headshot */}
        <div className="shrink-0 relative z-10">
          <div className="absolute inset-0 bg-gradient-to-r from-primary/50 to-accent/50 rounded-full blur-xl opacity-70 animate-pulse-slow"></div>
          <img
            src="/abhiram_headshot.jpg"
            alt="Abhiram Reddy Chinta"
            className="relative w-52 h-52 rounded-full object-cover shadow-2xl shadow-accent/20 ring-2 ring-white/10"
          />
        </div>
        
        {/* Intro */}
        <div className="text-center lg:text-left max-w-lg relative z-10">
          <h1 className="text-4xl sm:text-5xl font-extrabold leading-tight">
            Hi, I'm <span className="text-gradient bg-clip-text text-transparent bg-gradient-to-r from-primary to-accent">Abhiram</span>
          </h1>
          <p className="mt-4 text-lg sm:text-xl text-foreground font-serif font-medium">
            Security+ & AZ‑500 Certified Cyber‑Security Analyst | Currently Working at Vosyn (Cyber Security Analyst) and Allied Universal (Security Associate)
          </p>
          <div className="mt-8 flex flex-wrap justify-center lg:justify-start gap-4">
            <a
              href="/files/Abhiram_Reddy_Resume.pdf"
              download
              className="inline-flex items-center gap-2 px-6 py-3 bg-primary hover:bg-primary/90 rounded-full shadow-lg shadow-primary/20 transition-all hover:translate-y-[-2px]"
            >
              <Download size={18} /> Resume
            </a>
            <a
              href="#contact"
              className="inline-flex items-center gap-2 px-6 py-3 border border-primary hover:bg-primary/10 rounded-full transition-all hover:translate-y-[-2px]"
            >
              <Mail size={18} /> Contact
            </a>
          </div>
        </div>
      </section>

      {/* About */}
      <Section id="about" title="About Me">
        <div className="glass-card p-8 rounded-2xl">
          <p className="leading-relaxed mb-4 text-justify">
            Threat‑hunting, automation‑driven defender with SIEM chops (Azure Sentinel, Splunk, ELK, Security Onion). I script
            Python/Bash for OSINT enrichment—trimming manual look‑ups by roughly a third in both my home SOC lab and zero‑trust
            pilots at <strong className="text-primary">LYNFF Soft</strong>. Fluent in ISO 27001, NIST CSF and PCI‑DSS, I turn log noise into risk insights
            and stay calm when the pager rings at 3 a.m.
          </p>
          <p className="leading-relaxed text-justify">
            Currently working as a <strong className="text-primary">Cyber Security Analyst</strong> at Vosyn, where I implement compliance frameworks and conduct risk assessments 
            to strengthen organizational security posture. I also serve as a <strong className="text-primary">Security Associate</strong> at Allied Universal, 
            managing physical access controls and security event monitoring. I have a keen interest in <strong className="text-primary">Identity and Access Management (IAM)</strong>, 
            exploring how robust authentication and authorization frameworks can prevent unauthorized access while maintaining operational efficiency.
          </p>
        </div>
      </Section>

      {/* Experience */}
      <Section id="experience" title="Experience">
        <Timeline>
          {/* Vosyn Internship */}
          <Job
            role="Cyber Security Analyst"
            company="Vosyn"
            period="May 2025 – Present"
            location="Internship"
            bullets={[
              "Implemented 3 key GRC frameworks (NIST CSF, ISO 27001, CIS Controls) resulting in 40% improved compliance posture.",
              "Conducted 12+ risk assessments identifying 85+ vulnerabilities with 95% remediation rate within SLA targets.",
              "Reduced documentation preparation time by 35% through template standardization and process automation.",
              "Facilitated cross-functional workshops with 8 departments, increasing security policy adherence by 27%."
            ]}
          />
          {/* Security Associate */}
          <Job
            role="Security Associate (Physical)"
            company="Allied Universal"
            period="May 2024 – Present"
            location="Toronto, ON"
            bullets={[
              "Maintain 100% audit‑pass rate on physical access controls across 3 high-security facilities.",
              "Log and categorize ~20 security events/month with 99.7% accuracy; escalate critical issues to SOC within 5-minute SLA.",
              "Reduced unauthorized access attempts by 42% through implementation of enhanced verification protocols."
            ]}
          />
          {/* Cyber Security Analyst */}
          <Job
            role="Cyber Security Analyst"
            company="LYNFF Soft Private Limited"
            period="Dec 2022 – Dec 2023"
            location="Hyderabad, IN"
            bullets={[
              "Reduced high‑severity SaaS vulnerabilities by 28% via weekly SonarQube scans and rapid patch coordination.",
              "Engineered KQL‑driven Azure Sentinel workbooks that halved alert‑triage time from 12 to 6 minutes on average.",
              "Authored ISO 27001‑aligned IR SOP adopted company‑wide, reducing incident response time by 35%.",
              "Conducted 15+ security awareness training sessions resulting in 47% decrease in successful phishing attempts."
            ]}
          />
          {/* IT Security Intern */}
          <Job
            role="IT Security Intern"
            company="LYNFF Soft Private Limited"
            period="Aug 2022 – Nov 2022"
            location="Hyderabad, IN"
            bullets={[
              "Performed vulnerability assessments on 15+ apps, cutting exploit risk by 15%.",
              "Automated log‑parsing in Python—30% faster analysis."
            ]}
          />
          {/* Full‑Stack Developer Intern */}
          <Job
            role="Full‑Stack Developer Intern"
            company="HighRadius"
            period="Jan 2022 – Apr 2022"
            location="Hyderabad, IN"
            bullets={[
              "Built AI‑driven invoice‑processing app; boosted data‑entry speed by 35%.",
              "Hardened backend configs; zero critical CVEs post‑deployment."
            ]}
          />
        </Timeline>
      </Section>

      {/* Projects */}
      <Section id="projects" title="Selected Projects">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          <ProjectCard 
            title="Zero Trust Network Implementation"
            description="Designed and implemented a zero-trust architecture for a mid-size enterprise, reducing lateral movement risk by 65% while maintaining operational efficiency."
            tags={["Azure AD", "Conditional Access", "MFA", "NIST SP 800-207"]}
          />
          <ProjectCard 
            title="Threat Hunting Dashboard"
            description="Built a custom Splunk dashboard for proactive threat hunting, combining MITRE ATT&CK framework with custom detection rules to identify potential threats before they escalate."
            tags={["Splunk", "MITRE ATT&CK", "KQL", "Python"]}
          />
          <ProjectCard 
            title="OSINT Automation Framework"
            description="Developed a Python-based framework that automates OSINT data collection and enrichment, reducing manual investigation time by 40% for security analysts."
            tags={["Python", "OSINT", "API Integration", "Data Enrichment"]}
          />
        </div>
      </Section>
      
      {/* Projects Timeline */}
      <Section id="projects-timeline" title="Projects Timeline">
        <div className="glass-card p-8 rounded-2xl">
          <div className="border-l-2 border-primary/30 ml-4">
            <TimelineProject 
              title="SOC Home Lab Simulation"
              date="June 2024"
              description="Deployed Security Onion and ELK Stack in a virtual environment to simulate SIEM alert workflows and case tracking. Practiced triaging events, documenting responses, and escalating based on threat severity."
              technologies={["Security Onion", "ELK Stack", "SIEM", "Incident Response"]}
            />
            
            <TimelineProject 
              title="SOC Process Documentation & SOP Creation"
              date="April 2024"
              description="Created structured SOPs based on simulated alerts using Splunk Free and pfSense logs. Applied Agile practices to prioritize and iterate on response strategies for various attack simulations."
              technologies={["Splunk", "pfSense", "Documentation", "Agile"]}
            />
            
            <TimelineProject 
              title="Zero Trust Architecture Implementation"
              date="February 2024"
              description="Designed and implemented a comprehensive zero-trust security model for a simulated enterprise environment, focusing on identity verification, least privilege access, and microsegmentation."
              technologies={["Azure AD", "Conditional Access", "MFA", "Network Segmentation"]}
            />
            
            <TimelineProject 
              title="Threat Intelligence Dashboard"
              date="November 2023"
              description="Developed an interactive dashboard that aggregates and visualizes threat intelligence from multiple sources, enabling faster identification of emerging threats and attack patterns."
              technologies={["Python", "Elasticsearch", "Kibana", "API Integration"]}
            />
            
            <TimelineProject 
              title="Automated Vulnerability Management System"
              date="August 2023"
              description="Built an automated system that scans, prioritizes, and tracks vulnerabilities across network infrastructure, with customized reporting and remediation workflows."
              technologies={["Nessus", "Python", "Docker", "CI/CD"]}
            />
          </div>
        </div>
      </Section>

      {/* Skills */}
      <Section id="skills" title="Skills">
        <div className="grid gap-8 md:grid-cols-2">
          <div className="glass-card p-6 rounded-xl">
            <h3 className="font-semibold text-lg text-primary mb-4">SIEM & Monitoring</h3>
            <SkillBar name="Azure Sentinel" level={92} />
            <SkillBar name="Splunk" level={88} />
            <SkillBar name="ELK Stack" level={85} />
            <SkillBar name="Security Onion" level={80} />
          </div>
          
          <div className="glass-card p-6 rounded-xl">
            <h3 className="font-semibold text-lg text-primary mb-4">Programming & Scripting</h3>
            <SkillBar name="Python" level={90} color="accent" />
            <SkillBar name="Bash" level={85} color="accent" />
            <SkillBar name="KQL" level={82} color="accent" />
            <SkillBar name="PowerShell" level={75} color="accent" />
          </div>
          
          <div className="glass-card p-6 rounded-xl">
            <h3 className="font-semibold text-lg text-primary mb-4">Security Tools</h3>
            <SkillBar name="Kali Linux" level={87} />
            <SkillBar name="Nmap" level={89} />
            <SkillBar name="Wireshark" level={85} />
            <SkillBar name="pfSense" level={82} />
            <SkillBar name="VMware" level={80} />
            <SkillBar name="Burp Suite" level={78} />
            <SkillBar name="Nessus" level={83} />
            <SkillBar name="SonarQube" level={80} />
          </div>
          
          <div className="glass-card p-6 rounded-xl">
            <h3 className="font-semibold text-lg text-primary mb-4">Frameworks & Standards</h3>
            <SkillBar name="ISO 27001" level={90} color="accent" />
            <SkillBar name="NIST CSF" level={88} color="accent" />
            <SkillBar name="PCI-DSS" level={82} color="accent" />
            <SkillBar name="CIS Controls" level={85} color="accent" />
          </div>
        </div>
      </Section>
      
      {/* Home Lab */}
      <Section id="homelab" title="SOC Home Lab">
        <div className="glass-card p-8 rounded-2xl">
          <p className="leading-relaxed mb-4 text-justify">
            I've built a comprehensive SOC-style home lab environment using entirely free, open-source tools to develop and refine my cybersecurity skills. 
            This lab runs on repurposed hardware with virtualization to maximize resource efficiency while simulating enterprise security monitoring capabilities.
          </p>
          
          <div className="grid gap-6 sm:grid-cols-2 mt-6">
            <div className="glass-card p-6 rounded-xl">
              <h3 className="font-semibold text-lg text-primary mb-2">Infrastructure & Monitoring</h3>
              <ul className="space-y-2">
                <li className="text-sm text-foreground/80 flex items-start gap-2">
                  <ChevronRight size={16} className="text-primary mt-1 flex-shrink-0" />
                  <span className="text-justify">Deployed <strong>Security Onion</strong> (free NSM solution) with integrated Suricata IDS, Zeek, and Wazuh HIDS to provide comprehensive network visibility and threat detection.</span>
                </li>
                <li className="text-sm text-foreground/80 flex items-start gap-2">
                  <ChevronRight size={16} className="text-primary mt-1 flex-shrink-0" />
                  <span className="text-justify">Configured <strong>pfSense</strong> (open-source firewall) with segmented networks and IDS/IPS capabilities to monitor traffic and simulate network security controls.</span>
                </li>
                <li className="text-sm text-foreground/80 flex items-start gap-2">
                  <ChevronRight size={16} className="text-primary mt-1 flex-shrink-0" />
                  <span className="text-justify">Implemented <strong>ELK Stack</strong> (Elasticsearch, Logstash, Kibana) for centralized log collection and visualization, with custom dashboards for security event monitoring.</span>
                </li>
                <li className="text-sm text-foreground/80 flex items-start gap-2">
                  <ChevronRight size={16} className="text-primary mt-1 flex-shrink-0" />
                  <span className="text-justify">Utilized <strong>Splunk Free</strong> (500MB daily indexing) for advanced correlation rules and alert creation, developing custom searches for threat hunting.</span>
                </li>
              </ul>
            </div>
            
            <div className="glass-card p-6 rounded-xl">
              <h3 className="font-semibold text-lg text-primary mb-2">Testing & Documentation</h3>
              <ul className="space-y-2">
                <li className="text-sm text-foreground/80 flex items-start gap-2">
                  <ChevronRight size={16} className="text-primary mt-1 flex-shrink-0" />
                  <span className="text-justify">Used <strong>Kali Linux</strong> (free penetration testing OS) to simulate attacks and validate detection capabilities, ensuring alerts trigger appropriately.</span>
                </li>
                <li className="text-sm text-foreground/80 flex items-start gap-2">
                  <ChevronRight size={16} className="text-primary mt-1 flex-shrink-0" />
                  <span className="text-justify">Created a <strong>TheHive</strong> (open-source incident response platform) instance integrated with MISP for case management and threat intelligence sharing.</span>
                </li>
                <li className="text-sm text-foreground/80 flex items-start gap-2">
                  <ChevronRight size={16} className="text-primary mt-1 flex-shrink-0" />
                  <span className="text-justify">Developed comprehensive playbooks and SOPs using <strong>GitLab Community Edition</strong> for version control and documentation of incident response procedures.</span>
                </li>
                <li className="text-sm text-foreground/80 flex items-start gap-2">
                  <ChevronRight size={16} className="text-primary mt-1 flex-shrink-0" />
                  <span className="text-justify">Automated alert workflows with <strong>Python scripts</strong> to enrich security events with OSINT data from free APIs like AbuseIPDB and VirusTotal.</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </Section>

      {/* Certifications */}
      <Section id="certifications" title="Certifications">
        <div className="grid gap-6 sm:grid-cols-2">
          <CertificationCard
            title="CompTIA Security+"
            issuer="CompTIA"
            date="Valid until Jan 6, 2028"
            description="Security+ certification validates the baseline skills necessary to perform core security functions."
          />
          <CertificationCard
            title="Microsoft AZ-500"
            issuer="Microsoft"
            date="Valid until April 16, 2026"
            description="Azure Security Technologies certification for implementing security controls and maintaining security posture."
          />
          <CertificationCard
            title="Cybersecurity Job Simulation"
            issuer="Mastercard"
            date="March 30th, 2024"
            description="Completed practical tasks in designing a phishing email simulation and interpreting phishing simulation results."
          />
          <CertificationCard
            title="Cybersecurity Analyst Job Simulation"
            issuer="TCS"
            date="March 30th, 2024"
            description="Completed hands-on cybersecurity analysis tasks in a simulated enterprise environment."
          />
          <CertificationCard
            title="Google Cybersecurity Professional Certificate"
            issuer="Google"
            date="September 10, 2024"
            description="Completed eight courses covering Python, Linux, SQL, SIEM tools, and IDS. Developed competency in beginner-level cybersecurity skills for entry-level roles."
          />
        </div>
      </Section>
      
      {/* Testimonials */}
      <Section id="testimonials" title="Testimonials">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          <Testimonial 
            quote="Abhiram brought a level of cybersecurity expertise that truly elevated our organization's defenses. His strategic, detail-oriented approach to threat hunting and incident response uncovered critical gaps and allowed us to proactively strengthen our systems. We're now significantly more resilient against potential threats, thanks to his work."
            author="Tilak Kumar Kanuri"
            title="Manager"
            company="Lynffsoft Private Limited"
          />
          <Testimonial 
            quote="Abhiram stood out not just for his technical proficiency, but for his genuine passion for cybersecurity. He approached every challenge with curiosity and a deep desire to learn—not just to complete an assignment, but to truly understand how and why things work. It was a pleasure to mentor him, and I'm confident he'll make meaningful contributions to the field."
            author="Dr. V. Hemamalini"
            title="Professor of Cybersecurity"
            company="SRM University"
          />
        </div>
      </Section>

      {/* Education */}
      <Section id="education" title="Education">
        <div className="grid gap-6 sm:grid-cols-2">
          <Edu
            title="Post‑Graduate Diploma, Cybersecurity"
            school="Sault College – Toronto Campus"
            period="Sep 2023 – Aug 2025 (In progress)"
          />
          <Edu
            title="B.Tech Computer Science Engineering – Cybersecurity"
            school="SRM University"
            period="Graduated May 2023"
          />
        </div>
      </Section>
      
      {/* Blog & Articles */}
      <Section id="blog" title="Blog & Articles">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          <BlogPost 
            title="Zero Trust Architecture: Beyond the Buzzword"
            date="April 15, 2025"
            excerpt="An in-depth analysis of implementing zero trust principles in enterprise environments, with practical steps for security teams to move beyond perimeter-based security models."
            readTime="8 min read"
            tags={["Zero Trust", "Enterprise Security"]}
            mediumLink="https://medium.com/@chintaabhiramreddy"
          />
          <BlogPost 
            title="SIEM Optimization Techniques for SOC Teams"
            date="March 2, 2025"
            excerpt="How to reduce alert fatigue and improve detection capabilities by fine-tuning SIEM rules and implementing automation for common triage workflows."
            readTime="6 min read"
            tags={["SIEM", "SOC", "Automation"]}
            mediumLink="https://medium.com/@chintaabhiramreddy"
          />
          <BlogPost 
            title="Threat Hunting with KQL: Advanced Techniques"
            date="January 18, 2025"
            excerpt="Leveraging Kusto Query Language for proactive threat hunting in Azure Sentinel, with examples of detecting living-off-the-land techniques and fileless malware."
            readTime="10 min read"
            tags={["Threat Hunting", "KQL", "Azure Sentinel"]}
            mediumLink="https://medium.com/@chintaabhiramreddy"
          />
        </div>

      </Section>
      
      {/* Quote of the Decade */}
      <Section id="quote" title="Quote of the Decade">
        <div className="glass-card p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300 max-w-3xl mx-auto">
          <div className="text-center">
            <svg className="w-12 h-12 text-primary/40 mx-auto mb-4" fill="currentColor" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
              <path d="M10 8c-4.4 0-8 3.6-8 8v8h8v-8h-4c0-2.2 1.8-4 4-4v-4zm18-4c-4.4 0-8 3.6-8 8v8h8v-8h-4c0-2.2 1.8-4 4-4v-4z" />
            </svg>
            <p className="text-xl md:text-2xl font-serif italic text-gradient mb-6">
              Like a lighthouse in a restless sea, cybersecurity shines not by predicting storms, but by facing the unexpected.
            </p>
            <p className="text-sm text-foreground/70">This quote inspired me to pursue a career in cybersecurity</p>
          </div>
        </div>
      </Section>
      
      {/* Currently Learning */}
      <Section id="learning" title="Currently Learning">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          <LearningItem 
            title="CompTIA CySA+ (Cybersecurity Analyst+)"
            progress={65}
            description="Advancing threat detection, vulnerability management, and security architecture skills with focus on security analytics and practical defensive techniques for enterprise environments."
            resources={[
              "Professor Messer's CySA+ YouTube channel",
              "Jason Dion's CySA+ course on Udemy",
              "NetworkChuck YouTube tutorials on security analytics",
              "John Hammond's YouTube walkthroughs on threat detection"
            ]}
          />
          <LearningItem 
            title="Certified Ethical Hacker (CEH)"
            progress={75}
            description="Developing practical penetration testing skills and ethical hacking methodologies to identify and remediate security vulnerabilities in enterprise systems."
            resources={[
              "Official EC-Council CEH courseware",
              "TryHackMe Pro labs for hands-on practice",
              "Weekly CTF challenges on HackTheBox"
            ]}
          />
          <LearningItem 
            title="Cloud Security Architecture"
            progress={60}
            description="Mastering multi-cloud security principles with focus on AWS and Azure security services, IAM best practices, and secure cloud architecture patterns."
            resources={[
              "AWS Security Specialty certification path",
              "Azure Security Engineer Associate materials",
              "Cloud Security Alliance guidance documents"
            ]}
          />
          <LearningItem 
            title="Advanced Threat Hunting"
            progress={45}
            description="Developing advanced threat hunting methodologies using MITRE ATT&CK framework, behavioral analytics, and proactive detection strategies."
            resources={[
              "SANS FOR508: Advanced Digital Forensics",
              "MITRE ATT&CK Defender certification",
              "Threat Hunting with Jupyter Notebooks course"
            ]}
          />
        </div>
      </Section>

      {/* Contact */}
      <Section id="contact" title="Contact">
        <div className="glass-card p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300 max-w-xl mx-auto">
          <div className="space-y-5 text-center">
            <p className="flex justify-center items-center gap-2">
              <Mail className="text-primary" size={20} />
              <a href="mailto:chintaabhiramreddy@gmail.com" className="text-primary hover:underline">
                chintaabhiramreddy@gmail.com
              </a>
            </p>
            <p className="flex justify-center items-center gap-2">
              <Phone className="text-primary" size={20} /> +1 416‑890‑0277
            </p>
            <p className="flex justify-center items-center gap-2">
              <ExternalLink className="text-primary" size={20} />
              <a
                href="https://www.linkedin.com/in/abhiram-reddy-chinta/"
                className="text-primary hover:underline"
                target="_blank"
                rel="noreferrer"
              >
                www.linkedin.com/in/abhiram-reddy-chinta
              </a>
            </p>
            <p className="flex justify-center items-center gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" className="text-primary" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 12m-10 0a10 10 0 1 0 20 0a10 10 0 1 0 -20 0"></path>
                <path d="M8 9h1l3 3l3 -3h1"></path>
                <path d="M8 15l2 0"></path>
                <path d="M14 15l2 0"></path>
                <path d="M9 9l0 6"></path>
                <path d="M15 9l0 6"></path>
              </svg>
              <a
                href="https://medium.com/@chintaabhiramreddy"
                className="text-primary hover:underline"
                target="_blank"
                rel="noreferrer"
              >
                medium.com/@chintaabhiramreddy
              </a>
            </p>
          </div>
        </div>
      </Section>

      <footer className="py-10 text-center text-sm text-foreground/60 mt-32 border-t border-border">
        <div className="max-w-6xl mx-auto px-6">
          <p>© {new Date().getFullYear()} Abhiram Reddy Chinta. All rights reserved.</p>
          <p className="mt-2 text-xs">Cybersecurity Analyst & Threat Hunter</p>
        </div>
      </footer>
    </div>
  );
}

/* ---------- Helper components ---------- */
function Section({ id, title, children }: { id: string; title: string; children: React.ReactNode }) {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.1 }
    );
    
    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }
    
    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);
  
  return (
    <section 
      id={id} 
      ref={sectionRef}
      className={`max-w-6xl mx-auto px-6 py-20 transition-all duration-1000 ${
        isVisible 
          ? "opacity-100 translate-y-0" 
          : "opacity-0 translate-y-10"
      }`}
    >
      <h2 className={`text-center text-3xl font-bold text-gradient mb-12 transition-all duration-700 delay-300 ${
        isVisible ? "opacity-100 scale-100" : "opacity-0 scale-95"
      }`}>
        {title}
      </h2>
      <div className={`transition-all duration-1000 delay-500 ${
        isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
      }`}>
        {children}
      </div>
    </section>
  );
}

function Timeline({ children }: { children: React.ReactNode }) {
  return <div className="border-l border-primary/30 pl-6 space-y-12 relative">{children}</div>;
}

function Job({ 
  role, 
  company, 
  period, 
  location, 
  bullets 
}: { 
  role: string; 
  company: string; 
  period: string; 
  location: string; 
  bullets: string[] 
}) {
  return (
    <div className="relative group">
      <div className="absolute -left-10 top-1 h-4 w-4 rounded-full bg-primary group-hover:bg-accent transition-colors duration-300"></div>
      <div className="glass-card p-6 rounded-xl hover:shadow-lg hover:shadow-primary/10 transition-all duration-300 hover:translate-y-[-2px]">
        <h3 className="text-xl font-semibold">{role}</h3>
        <p className="text-primary font-medium">{company}</p>
        <p className="text-sm text-foreground/60 mt-1">
          {period} | {location}
        </p>
        <ul className="mt-3 space-y-1">
          {bullets.map((bullet, i) => (
            <li key={i} className="text-sm text-foreground/80 flex items-start gap-2">
              <ChevronRight size={16} className="text-primary mt-1 flex-shrink-0" />
              <span>{bullet}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

function Edu({ 
  title, 
  school, 
  period 
}: { 
  title: string; 
  school: string; 
  period: string 
}) {
  return (
    <div className="glass-card p-6 rounded-xl hover:shadow-lg hover:shadow-primary/10 transition-all duration-300 hover:translate-y-[-2px]">
      <h3 className="font-semibold text-lg">{title}</h3>
      <p className="text-primary">{school}</p>
      <p className="text-sm text-foreground/60 mt-1">{period}</p>
    </div>
  );
}

function ProjectCard({ 
  title, 
  description, 
  tags 
}: { 
  title: string; 
  description: string; 
  tags: string[];
}) {
  return (
    <div className="glass-card p-6 rounded-xl hover:shadow-lg hover:shadow-primary/10 transition-all duration-300 hover:translate-y-[-2px] group">
      <h3 className="font-semibold mb-2 group-hover:text-primary transition-colors">{title}</h3>
      <p className="text-sm text-foreground/70 mb-4 text-justify">{description}</p>
      <div className="flex flex-wrap gap-2 mb-3">
        {tags.map((tag, i) => (
          <span key={i} className="text-xs px-2 py-1 bg-secondary/50 rounded-full text-foreground/80">
            {tag}
          </span>
        ))}
      </div>
      {/* Project links removed as requested */}
    </div>
  );
}
