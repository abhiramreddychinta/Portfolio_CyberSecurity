import { useState } from 'react';

interface BlogPostProps {
  title: string;
  date: string;
  excerpt: string;
  readTime: string;
  tags: string[];
  mediumLink?: string;
}

export default function BlogPost({ title, date, excerpt, readTime, tags, mediumLink }: BlogPostProps) {
  const [expanded, setExpanded] = useState(false);
  
  // Full article content - this would normally come from a database or CMS
  const fullContent = `
    ${excerpt}
    
    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam auctor, nisl eget ultricies tincidunt, 
    nisl nisl aliquam nisl, eget aliquam nisl nisl eget nisl. Nullam auctor, nisl eget ultricies tincidunt, 
    nisl nisl aliquam nisl, eget aliquam nisl nisl eget nisl.
    
    Cybersecurity requires a proactive approach that combines technical controls with human awareness. 
    By implementing defense-in-depth strategies and continuously monitoring for threats, organizations 
    can significantly reduce their attack surface and respond effectively to emerging threats.
    
    Key takeaways:
    • Implement a multi-layered security approach
    • Regularly test and validate security controls
    • Develop comprehensive incident response procedures
    • Maintain awareness of emerging threats and vulnerabilities
  `;
  
  const toggleExpand = () => {
    setExpanded(!expanded);
  };
  
  const handleViewArticle = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (mediumLink) {
      window.open(mediumLink, '_blank', 'noopener,noreferrer');
    }
  };
  
  return (
    <div 
      className={`glass-card p-6 rounded-xl hover:shadow-lg hover:shadow-primary/10 transition-all duration-300 hover:translate-y-[-2px] group cursor-pointer ${expanded ? 'col-span-full' : ''}`}
      onClick={toggleExpand}
    >
      <div className="flex justify-between items-start mb-2">
        <h3 className="font-semibold group-hover:text-primary transition-colors">{title}</h3>
        <span className="text-xs text-foreground/60 whitespace-nowrap ml-2">{date}</span>
      </div>
      
      {expanded ? (
        <div className="text-sm text-foreground/70 mb-4 text-justify whitespace-pre-line">
          {fullContent}
        </div>
      ) : (
        <p className="text-sm text-foreground/70 mb-4 text-justify">{excerpt}</p>
      )}
      
      <div className="flex justify-between items-center">
        <div className="flex flex-wrap gap-2">
          {tags.map((tag, i) => (
            <span key={i} className="text-xs px-2 py-1 bg-secondary/50 rounded-full text-foreground/80">
              {tag}
            </span>
          ))}
        </div>
        <div className="flex items-center gap-3">
          <span className="text-xs text-foreground/60">{readTime}</span>
          {mediumLink && (
            <button 
              onClick={handleViewArticle}
              className="text-xs px-3 py-1 bg-primary hover:bg-primary/90 rounded-full text-white transition-colors"
            >
              View Article
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
